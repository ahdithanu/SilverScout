# ⚡ SILVER SCOUT | Enterprise Multi-Tenant Deal Control Plane

**Silver Scout** is an autonomous, production-grade deal-sourcing, underwriting, and operator control plane designed for private equity search funds acquiring lower middle market trade SMBs (HVAC, Plumbing, Electrical, Manufacturing, Roofing, Solar, and Landscaping).

---

## 🌟 Architecture & Control Plane Capabilities

### 1. ⚙️ Multi-Tenant Deployment Configuration (`FundDeploymentConfig`)
- Per-tenant deployment configuration (`funds/{fundId}/config/deployment`) governing financial screening thresholds, LBO leverage rules, scoring weights, and LOI approval policies.

### 2. 🛡️ Durable Finite State Machine & Execution Audit Trail (`server/fsm.ts`)
- Explicit state machine enforcing prerequisite guards across pipeline stages (`INGESTED` -> `ENRICHED` -> `SCORED` -> `UNDERWRITTEN` -> `IC_GENERATED` -> `APPROVAL_REQUIRED` -> `APPROVED` -> `OUTREACH_TRIGGERED` -> `CRM_SYNCED`).
- Records immutable `WorkflowExecutionRecord` entries for every state transition capturing input/output snapshots, timestamps, actor, and idempotency key.

### 3. 📬 Transactional Outbox & Side-Effect Idempotency (`server/outbox.ts`)
- Transactional outbox engine generating deterministic idempotency keys (`fundId:dealId:OUTREACH:v1:sendgrid`) for cold email dispatches and CRM syncs.
- Eliminates duplicate side effects during retries, featuring exponential backoff and Dead Letter Queue (`DEAD_LETTER`) routing.

### 4. 🔒 Deterministic Financial Assertion Guard (`server/financialGuard.ts`)
- Financial fact validation engine ensuring deterministic LBO numbers (`revenue`, `ebitda`) are 100% authoritative and cannot be silently overwritten by LLM hallucinations.

### 5. 🎛️ Operator Control Panel Dashboard (`OperatorControlPanel.tsx`)
- Mounted dashboard providing fund managers with tools to inspect tenant configs, track FSM stage lineage, manage outbox DLQs, execute pause/resume/retry interventions, and review correlation trace logs (`x-correlation-id`).

---

## 🚀 Quick Start & Development

### 1. Install Dependencies
```bash
npm install
```

### 2. Start API Control Plane & Vite Frontend
```bash
npm run dev
```

### 3. Run Automated TypeScript Test Suite (47/47 Passed)
```bash
./node_modules/.bin/tsx --test --test-reporter=spec src/__tests__/run-tests.ts
```

---

## 🐳 Production Deployment

### Multi-Stage Container Build
```bash
docker-compose up --build
```

### Deploy Backend Control Plane to GCP Cloud Run
```bash
gcloud run deploy silver-scout-backend \
  --source . \
  --region us-central1 \
  --allow-unauthenticated
```
